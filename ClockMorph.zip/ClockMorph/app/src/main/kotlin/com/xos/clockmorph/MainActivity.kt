package com.xos.clockmorph

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.widget.*

/** Layar pengaturan (dibuat lewat kode supaya tidak butuh banyak XML). */
class MainActivity : Activity() {

    private val dp by lazy { resources.displayMetrics.density }
    private fun px(v: Int) = (v * dp).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val sp = Prefs.open(this)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(20), px(24), px(20), px(24))
        }
        fun title(t: String) = TextView(this).apply {
            text = t; textSize = 16f; setPadding(0, px(18), 0, px(4))
            col.addView(this)
        }

        col.addView(TextView(this).apply {
            text = "Clock Morph XOS 16.3"; textSize = 22f
        })
        col.addView(TextView(this).apply {
            text = "Aktifkan modul di LSPosed (scope: System UI), lalu reboot / restart SystemUI. " +
                "Tambahkan widget \"Clock Morph XOS\" di homescreen, letakkan di bagian atas."
            textSize = 13f; setPadding(0, px(6), 0, px(6))
        })

        val sw = Switch(this).apply {
            text = "Aktifkan animasi"
            isChecked = sp.getBoolean(Prefs.ENABLED, Prefs.DEF_ENABLED)
            setOnCheckedChangeListener { _, c -> sp.edit().putBoolean(Prefs.ENABLED, c).apply() }
        }
        col.addView(sw)

        title("Mode animasi")
        val rg = RadioGroup(this)
        val r0 = RadioButton(this).apply { text = "1. Morph ke widget (jam vertikal → jam horizontal)"; id = 100 }
        val r1 = RadioButton(this).apply { text = "2. Geser & pudar (jam naik lalu hilang)"; id = 101 }
        rg.addView(r0); rg.addView(r1)
        rg.check(if (sp.getInt(Prefs.MODE, Prefs.DEF_MODE) == 0) 100 else 101)
        rg.setOnCheckedChangeListener { _, id ->
            sp.edit().putInt(Prefs.MODE, if (id == 100) 0 else 1).apply()
        }
        col.addView(rg)

        fun slider(label: String, key: String, def: Int, min: Int, max: Int, unit: String) {
            val tv = TextView(this).apply { textSize = 14f }
            val cur = sp.getInt(key, def)
            tv.text = "$label: $cur$unit"
            title(label)
            col.removeView(col.getChildAt(col.childCount - 1)) // judul diganti label berisi nilai
            col.addView(tv.apply { setPadding(0, px(18), 0, px(4)) })
            col.addView(SeekBar(this).apply {
                this.max = max - min
                progress = cur - min
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                        tv.text = "$label: ${p + min}$unit"
                        if (u) sp.edit().putInt(key, p + min).apply()
                    }
                    override fun onStartTrackingTouch(s: SeekBar?) {}
                    override fun onStopTrackingTouch(s: SeekBar?) {}
                })
            })
        }

        slider("Durasi animasi", Prefs.DURATION, Prefs.DEF_DURATION, 200, 900, " ms")
        slider("Posisi widget – horizontal (pusat)", Prefs.TARGET_X, Prefs.DEF_X, 0, 100, " %")
        slider("Posisi widget – vertikal (pusat)", Prefs.TARGET_Y, Prefs.DEF_Y, 2, 60, " %")
        slider("Tinggi teks jam widget", Prefs.TARGET_H, Prefs.DEF_H, 30, 140, " dp")

        col.addView(TextView(this).apply {
            text = "Posisi & tinggi di atas harus disamakan dengan letak widget di homescreen " +
                "supaya jam yang mengecil mendarat tepat di widget."
            textSize = 12f; gravity = Gravity.START; setPadding(0, px(18), 0, 0)
        })

        setContentView(ScrollView(this).apply { addView(col) })
    }
}
