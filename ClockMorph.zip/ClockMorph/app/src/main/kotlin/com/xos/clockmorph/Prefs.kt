package com.xos.clockmorph

import android.content.Context
import android.content.SharedPreferences

/** Kunci & nilai bawaan pengaturan. Dipakai app pengaturan (tulis) dan hook SystemUI (baca). */
object Prefs {
    const val PKG = "com.xos.clockmorph"
    const val FILE = "cfg"

    const val ENABLED = "enabled"      // Boolean
    const val MODE = "mode"            // 0 = Morph ke widget, 1 = Geser & pudar
    const val DURATION = "duration"    // ms
    const val TARGET_X = "target_x"    // % lebar layar (pusat widget)
    const val TARGET_Y = "target_y"    // % tinggi layar (pusat widget)
    const val TARGET_H = "target_h"    // dp, tinggi teks jam widget

    const val DEF_ENABLED = true
    const val DEF_MODE = 0
    const val DEF_DURATION = 450
    const val DEF_X = 50
    const val DEF_Y = 14
    const val DEF_H = 64

    /** Dipanggil dari app: file dibuat bisa dibaca XSharedPreferences (LSPosed). */
    @Suppress("DEPRECATION", "WorldReadableFiles")
    fun open(ctx: Context): SharedPreferences = try {
        ctx.getSharedPreferences(FILE, Context.MODE_WORLD_READABLE)
    } catch (_: Throwable) {
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)
    }
}
