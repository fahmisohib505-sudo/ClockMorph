package com.xos.clockmorph

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.provider.AlarmClock
import android.widget.RemoteViews

/** Widget jam homescreen. Tampilannya sengaja sama dengan teks yang dianimasikan overlay SystemUI. */
class ClockWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        for (id in ids) {
            val views = RemoteViews(ctx.packageName, R.layout.widget_clock)
            val i = Intent(AlarmClock.ACTION_SHOW_ALARMS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            views.setOnClickPendingIntent(
                R.id.root,
                PendingIntent.getActivity(ctx, 0, i, PendingIntent.FLAG_IMMUTABLE)
            )
            mgr.updateAppWidget(id, views)
        }
    }
}
