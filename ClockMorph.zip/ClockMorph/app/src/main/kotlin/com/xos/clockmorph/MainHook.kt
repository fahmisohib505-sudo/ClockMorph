package com.xos.clockmorph

import android.view.View
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XSharedPreferences
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage
import java.lang.ref.WeakReference

/**
 * Hook SystemUI XOS 16.3 (UI Sistem 16.03.00.123).
 * Nama class/method diambil langsung dari dex SystemUI tersebut:
 *  - com.transsion.keyguard.clock.ui.KeyguardClockView  (jam lockscreen & AOD, jam vertikal)
 *  - com.android.systemui.statusbar.policy.KeyguardStateControllerImpl
 *      notifyKeyguardGoingAway(boolean) -> saat unlock
 *      notifyKeyguardState(boolean,boolean) -> saat keyguard tampil lagi
 */
class MainHook : IXposedHookLoadPackage {

    private var clockRef: WeakReference<View>? = null
    private var lastShowing = true
    private var lastSnapshot: MorphOverlay.Snapshot? = null

    private val prefs by lazy { XSharedPreferences(Prefs.PKG, Prefs.FILE) }

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        if (lpparam.packageName != "com.android.systemui") return
        val cl = lpparam.classLoader
        try {
            MorphOverlay.snapshotProvider = { clockRef?.get()?.let { MorphOverlay.snapshot(it) } }
            MorphOverlay.configProvider = { readConfig() }
            hookClockView(cl)
            hookKeyguardState(cl)
            XposedBridge.log("ClockMorph: hook terpasang")
        } catch (t: Throwable) {
            XposedBridge.log("ClockMorph: gagal memasang hook: $t")
        }
    }

    private fun hookClockView(cl: ClassLoader) {
        val cls = "com.transsion.keyguard.clock.ui.KeyguardClockView"
        XposedHelpers.findAndHookMethod(cls, cl, "onAttachedToWindow", object : XC_MethodHook() {
            override fun afterHookedMethod(p: MethodHookParam) {
                val v = p.thisObject as View
                clockRef = WeakReference(v)
                // simpan info jam setelah layout selesai, dipakai kalau saat unlock view sudah memudar
                v.postDelayed({
                    try { MorphOverlay.snapshot(v)?.let { lastSnapshot = it } } catch (_: Throwable) {}
                }, 1500)
                MorphOverlay.schedulePrepare(1600)
            }
        })
        XposedHelpers.findAndHookMethod(cls, cl, "onTimeChanged", object : XC_MethodHook() {
            override fun afterHookedMethod(p: MethodHookParam) {
                MorphOverlay.schedulePrepare(500)
            }
        })
        XposedHelpers.findAndHookMethod(cls, cl, "onDetachedFromWindow", object : XC_MethodHook() {
            override fun beforeHookedMethod(p: MethodHookParam) {
                if (clockRef?.get() === p.thisObject) clockRef = null
            }
        })
    }

    private fun hookKeyguardState(cl: ClassLoader) {
        val cls = "com.android.systemui.statusbar.policy.KeyguardStateControllerImpl"

        // Unlock: ambil snapshot jam SEBELUM keyguard memudar, lalu mainkan animasi keluar.
        XposedHelpers.findAndHookMethod(cls, cl, "notifyKeyguardGoingAway",
            java.lang.Boolean.TYPE, object : XC_MethodHook() {
                override fun beforeHookedMethod(p: MethodHookParam) {
                    if (p.args[0] != true) return
                    safe {
                        val cfg = readConfig() ?: return@safe
                        val v = clockRef?.get() ?: return@safe
                        val snap = MorphOverlay.snapshot(v) ?: lastSnapshot ?: return@safe
                        lastSnapshot = snap
                        MorphOverlay.play(snap, cfg, reverse = false)
                    }
                }
            })

        // Lock: keyguard muncul lagi -> jalankan animasi mundur (widget -> jam vertikal).
        XposedHelpers.findAndHookMethod(cls, cl, "notifyKeyguardState",
            java.lang.Boolean.TYPE, java.lang.Boolean.TYPE, object : XC_MethodHook() {
                override fun afterHookedMethod(p: MethodHookParam) {
                    val showing = p.args[0] as Boolean
                    val occluded = p.args[1] as Boolean
                    val becameShowing = showing && !lastShowing && !occluded
                    lastShowing = showing
                    if (!becameShowing) return
                    safe {
                        val cfg = readConfig() ?: return@safe
                        // pakai snapshot terbaru bila jam sudah terpasang, kalau tidak pakai yang terakhir
                        val snap = clockRef?.get()?.let { MorphOverlay.snapshot(it) } ?: lastSnapshot
                        ?: return@safe
                        MorphOverlay.play(snap, cfg, reverse = true)
                    }
                }
            })
    }

    private fun readConfig(): MorphOverlay.Config? {
        prefs.reload()
        if (!prefs.getBoolean(Prefs.ENABLED, Prefs.DEF_ENABLED)) return null
        return MorphOverlay.Config(
            mode = prefs.getInt(Prefs.MODE, Prefs.DEF_MODE),
            durationMs = prefs.getInt(Prefs.DURATION, Prefs.DEF_DURATION).toLong(),
            targetXPercent = prefs.getInt(Prefs.TARGET_X, Prefs.DEF_X),
            targetYPercent = prefs.getInt(Prefs.TARGET_Y, Prefs.DEF_Y),
            targetHeightDp = prefs.getInt(Prefs.TARGET_H, Prefs.DEF_H),
        )
    }

    private inline fun safe(block: () -> Unit) {
        try { block() } catch (t: Throwable) { XposedBridge.log("ClockMorph: $t") }
    }
}
