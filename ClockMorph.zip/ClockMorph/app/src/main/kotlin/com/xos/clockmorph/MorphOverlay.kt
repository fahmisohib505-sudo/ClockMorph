package com.xos.clockmorph

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Shader
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.PathInterpolator
import android.widget.FrameLayout
import android.widget.TextView
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XposedHelpers

/**
 * Overlay animasi di proses SystemUI (v3).
 * Jendela overlay DISIAPKAN lebih dulu (tak terlihat) saat keyguard tampil, berisi tiruan angka jam &
 * menit lockscreen (font, ukuran, posisi sama). Saat unlock, overlay langsung ditampilkan di frame
 * yang sama dan angka-angkanya bergeser/mengecil menjadi satu baris "HH:mm" di posisi widget.
 */
object MorphOverlay {

    private const val TYPE_NAV_BAR_PANEL = 2024 // TYPE_NAVIGATION_BAR_PANEL (hidden API)

    class Config(
        val mode: Int,
        val durationMs: Long,
        val targetXPercent: Int,
        val targetYPercent: Int,
        val targetHeightDp: Int,
    ) {
        val key get() = "$mode/$targetXPercent/$targetYPercent/$targetHeightDp"
    }

    class Part(
        val text: CharSequence,
        val left: Int, val top: Int, val w: Int, val h: Int,
        val textSizePx: Float,
        val gravity: Int,
        val padL: Int, val padT: Int, val padR: Int, val padB: Int,
        val fontPadding: Boolean,
        val typeface: Typeface?,
        val variation: String?,
    )

    class Snapshot(val context: Context, val hour: Part, val minute: Part) {
        val key get() = "${hour.text}:${minute.text}/${hour.left},${hour.top},${minute.left},${minute.top}"
    }

    private class State(
        val root: FrameLayout,
        val key: String,
        val apply: (Float) -> Unit,
        val wm: WindowManager,
    )

    private val main = Handler(Looper.getMainLooper())
    private var state: State? = null
    private var animator: ValueAnimator? = null
    private var playing = false

    /** Diisi MainHook: cara mengambil snapshot & config terbaru. */
    var snapshotProvider: (() -> Snapshot?)? = null
    var configProvider: (() -> Config?)? = null

    private fun part(v: TextView): Part? {
        if (v.width <= 0 || v.height <= 0 || !v.isAttachedToWindow) return null
        val loc = IntArray(2)
        v.getLocationOnScreen(loc)
        return Part(
            text = v.text, left = loc[0], top = loc[1], w = v.width, h = v.height,
            textSizePx = v.textSize, gravity = v.gravity,
            padL = v.paddingLeft, padT = v.paddingTop, padR = v.paddingRight, padB = v.paddingBottom,
            fontPadding = v.includeFontPadding, typeface = v.typeface,
            variation = try { v.fontVariationSettings } catch (_: Throwable) { null },
        )
    }

    fun snapshot(clockView: View): Snapshot? {
        val hv = XposedHelpers.callMethod(clockView, "getTimeViewHour") as? TextView ?: return null
        val mv = XposedHelpers.callMethod(clockView, "getTimeViewMinute") as? TextView ?: return null
        val h = part(hv) ?: return null
        val m = part(mv) ?: return null
        return Snapshot(clockView.context, h, m)
    }

    private fun onMain(block: () -> Unit) {
        if (Looper.myLooper() == Looper.getMainLooper()) block() else main.post(block)
    }

    /** Siapkan overlay tak terlihat (dipanggil saat keyguard tampil dan tiap ganti menit). */
    fun schedulePrepare(delayMs: Long) {
        main.postDelayed({
            try {
                if (playing) return@postDelayed
                val s = snapshotProvider?.invoke() ?: return@postDelayed
                val c = configProvider?.invoke() ?: return@postDelayed
                val k = s.key + "|" + c.key
                if (state?.key == k) return@postDelayed
                removeNow()
                state = build(s, c, k, visible = false)
            } catch (t: Throwable) { XposedBridge.log("ClockMorph prepare: $t") }
        }, delayMs)
    }

    fun play(s: Snapshot, cfg: Config, reverse: Boolean) {
        onMain {
            try {
                val k = s.key + "|" + cfg.key
                var st = state
                if (st == null || st.key != k) {
                    removeNow()
                    st = build(s, cfg, k, visible = false)
                    state = st
                }
                start(st, cfg, reverse)
            } catch (t: Throwable) {
                XposedBridge.log("ClockMorph play: $t")
                removeNow()
            }
        }
    }

    private fun removeNow() {
        animator?.cancel(); animator = null
        playing = false
        state?.let {
            try { it.wm.removeViewImmediate(it.root) } catch (_: Throwable) {}
        }
        state = null
    }

    private fun replica(ctx: Context, p: Part): TextView = TextView(ctx).apply {
        text = p.text
        setTextSize(TypedValue.COMPLEX_UNIT_PX, p.textSizePx)
        setTextColor(0xFFFFFFFF.toInt())
        typeface = p.typeface
        try { if (p.variation != null) fontVariationSettings = p.variation } catch (_: Throwable) {}
        includeFontPadding = p.fontPadding
        gravity = p.gravity
        setPadding(p.padL, p.padT, p.padR, p.padB)
        // gradasi putih bening seperti jam asli
        paint.shader = LinearGradient(
            0f, 0f, 0f, p.h.toFloat(), 0xF2FFFFFF.toInt(), 0x9EFFFFFF.toInt(), Shader.TileMode.CLAMP
        )
        layoutParams = FrameLayout.LayoutParams(p.w, p.h, Gravity.TOP or Gravity.START).also {
            it.leftMargin = p.left; it.topMargin = p.top
        }
        pivotX = p.w / 2f; pivotY = p.h / 2f
    }

    private fun build(s: Snapshot, cfg: Config, key: String, visible: Boolean): State {
        val ctx = s.context
        val wm = ctx.getSystemService(WindowManager::class.java)
        val dm = ctx.resources.displayMetrics
        val density = dm.density

        val root = FrameLayout(ctx)
        val hv = replica(ctx, s.hour)
        val mv = replica(ctx, s.minute)
        root.addView(hv); root.addView(mv)

        val tgtSize = cfg.targetHeightDp * density
        val scale = tgtSize / s.hour.textSizePx
        val paint = Paint().apply {
            textSize = tgtSize; typeface = s.hour.typeface
            try { if (s.hour.variation != null) fontVariationSettings = s.hour.variation } catch (_: Throwable) {}
        }
        val wH = paint.measureText(s.hour.text.toString())
        val wC = paint.measureText(":")
        val wM = paint.measureText(s.minute.text.toString())
        val total = wH + wC + wM
        val tgtCx = dm.widthPixels * cfg.targetXPercent / 100f
        val tgtCy = dm.heightPixels * cfg.targetYPercent / 100f
        val startX = tgtCx - total / 2f
        val hCx = startX + wH / 2f
        val cCx = startX + wH + wC / 2f
        val mCx = startX + wH + wC + wM / 2f

        val colon = TextView(ctx).apply {
            text = ":"
            setTextSize(TypedValue.COMPLEX_UNIT_PX, tgtSize)
            setTextColor(0xE6FFFFFF.toInt())
            typeface = s.hour.typeface
            includeFontPadding = s.hour.fontPadding
            measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED)
            layoutParams = FrameLayout.LayoutParams(measuredWidth, measuredHeight, Gravity.TOP or Gravity.START)
                .also {
                    it.leftMargin = (cCx - measuredWidth / 2f).toInt()
                    it.topMargin = (tgtCy - measuredHeight / 2f).toInt()
                }
            alpha = 0f
        }
        root.addView(colon)

        val hSrcCx = s.hour.left + s.hour.w / 2f
        val hSrcCy = s.hour.top + s.hour.h / 2f
        val mSrcCx = s.minute.left + s.minute.w / 2f
        val mSrcCy = s.minute.top + s.minute.h / 2f

        fun clamp(v: Float) = v.coerceIn(0f, 1f)
        val apply: (Float) -> Unit = { p ->
            if (cfg.mode == 0) {
                val sc = 1f + (scale - 1f) * p
                hv.translationX = (hCx - hSrcCx) * p
                hv.translationY = (tgtCy - hSrcCy) * p
                hv.scaleX = sc; hv.scaleY = sc
                mv.translationX = (mCx - mSrcCx) * p
                mv.translationY = (tgtCy - mSrcCy) * p
                mv.scaleX = sc; mv.scaleY = sc
                colon.alpha = clamp((p - 0.55f) / 0.45f)
            } else {
                val dy = -60f * density * p
                hv.translationY = dy; mv.translationY = dy
                hv.alpha = 1f - p; mv.alpha = 1f - p
                colon.alpha = 0f
            }
        }
        apply(0f)

        root.visibility = if (visible) View.VISIBLE else View.INVISIBLE
        val lp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT,
            TYPE_NAV_BAR_PANEL,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { setTitle("ClockMorphOverlay") }
        wm.addView(root, lp)
        return State(root, key, apply, wm)
    }

    private fun start(st: State, cfg: Config, reverse: Boolean) {
        playing = true
        val root = st.root
        root.animate().cancel()
        root.alpha = 1f
        val from = if (reverse) 1f else 0f
        val to = if (reverse) 0f else 1f
        st.apply(from)
        root.visibility = View.VISIBLE // tampil di frame yang sama dengan hilangnya jam asli

        animator = ValueAnimator.ofFloat(from, to).apply {
            duration = cfg.durationMs
            interpolator = PathInterpolator(0.2f, 0f, 0f, 1f)
            addUpdateListener { st.apply(it.animatedValue as Float) }
            addListener(object : AnimatorListenerAdapter() {
                private var canceled = false
                override fun onAnimationCancel(a: Animator) { canceled = true }
                override fun onAnimationEnd(a: Animator) {
                    if (canceled) return
                    if (reverse) {
                        finish(st)
                    } else {
                        // tahan sampai animasi buka launcher selesai, lalu pudar ke widget asli
                        root.animate().alpha(0f).setStartDelay(400).setDuration(250)
                            .withEndAction { finish(st) }.start()
                    }
                }
            })
            start()
        }
    }

    private fun finish(st: State) {
        if (state === st) removeNow()
        schedulePrepare(1200) // siapkan overlay berikutnya
    }
}
