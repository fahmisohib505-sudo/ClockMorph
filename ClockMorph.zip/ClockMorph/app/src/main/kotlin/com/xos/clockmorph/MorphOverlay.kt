package com.xos.clockmorph

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.text.format.DateFormat
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.PathInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import de.robv.android.xposed.XposedHelpers
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Overlay animasi di proses SystemUI.
 * Jam vertikal lockscreen (snapshot) mengecil & berpindah ke posisi widget, sementara teks jam
 * horizontal "HH:mm" tumbuh dari posisi yang sama dan berhenti tepat di atas widget.
 * Mode 2 hanya menggeser dan memudarkan jam. Arah dibalik (reverse) saat layar dikunci lagi.
 */
object MorphOverlay {

    class Config(
        val mode: Int,
        val durationMs: Long,
        val targetXPercent: Int,
        val targetYPercent: Int,
        val targetHeightDp: Int,
    )

    class Snapshot(
        val bitmap: Bitmap,
        val left: Int,
        val top: Int,
        val color: Int,
        val typeface: Typeface?,
        val context: Context,
    )

    private val main = Handler(Looper.getMainLooper())
    private var current: View? = null
    private var animator: ValueAnimator? = null

    /** Ambil gambar kontainer jam (jam & menit) dari KeyguardClockView. */
    fun snapshot(clockView: View): Snapshot? {
        // getTimeContainer() ada di KeyguardClockView XOS 16.3; kalau gagal pakai seluruh view
        val container = (try {
            XposedHelpers.callMethod(clockView, "getTimeContainer") as? View
        } catch (_: Throwable) { null }) ?: clockView
        if (container.width <= 0 || container.height <= 0 || !container.isAttachedToWindow) return null

        val bmp = Bitmap.createBitmap(container.width, container.height, Bitmap.Config.ARGB_8888)
        container.draw(Canvas(bmp))
        val loc = IntArray(2)
        container.getLocationOnScreen(loc)

        val hour = try {
            XposedHelpers.callMethod(clockView, "getTimeViewHour") as? TextView
        } catch (_: Throwable) { null }
        return Snapshot(
            bitmap = bmp,
            left = loc[0],
            top = loc[1],
            color = hour?.currentTextColor ?: 0xFFFFFFFF.toInt(),
            typeface = hour?.typeface,
            context = clockView.context,
        )
    }

    fun play(s: Snapshot, cfg: Config, reverse: Boolean) {
        main.post { try { run(s, cfg, reverse) } catch (t: Throwable) {
            de.robv.android.xposed.XposedBridge.log("ClockMorph overlay: $t")
            removeNow()
        } }
    }

    private fun removeNow() {
        animator?.cancel(); animator = null
        current?.let {
            try { (it.context.getSystemService(WindowManager::class.java)).removeViewImmediate(it) }
            catch (_: Throwable) {}
        }
        current = null
    }

    private fun run(s: Snapshot, cfg: Config, reverse: Boolean) {
        removeNow()
        val ctx = s.context
        val wm = ctx.getSystemService(WindowManager::class.java)
        val dm = ctx.resources.displayMetrics
        val density = dm.density

        // Titik awal (jam vertikal) & tujuan (widget)
        val srcW = s.bitmap.width.toFloat()
        val srcH = s.bitmap.height.toFloat()
        val srcCx = s.left + srcW / 2f
        val srcCy = s.top + srcH / 2f
        val tgtCx = dm.widthPixels * cfg.targetXPercent / 100f
        val tgtCy = dm.heightPixels * cfg.targetYPercent / 100f
        val tgtH = cfg.targetHeightDp * density

        val root = FrameLayout(ctx)

        val iv = ImageView(ctx).apply {
            setImageBitmap(s.bitmap)
            layoutParams = FrameLayout.LayoutParams(srcW.toInt(), srcH.toInt(), Gravity.TOP or Gravity.START)
                .also { it.leftMargin = s.left; it.topMargin = s.top }
            pivotX = srcW / 2f; pivotY = srcH / 2f
        }
        root.addView(iv)

        val fmt = if (DateFormat.is24HourFormat(ctx)) "HH:mm" else "h:mm"
        val tv = TextView(ctx).apply {
            text = SimpleDateFormat(fmt, Locale.getDefault()).format(Date())
            setTextColor(s.color or 0xFF000000.toInt())
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            includeFontPadding = false
            setTextSize(TypedValue.COMPLEX_UNIT_PX, tgtH)
            measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED)
            val w = measuredWidth; val h = measuredHeight
            layoutParams = FrameLayout.LayoutParams(w, h, Gravity.TOP or Gravity.START).also {
                it.leftMargin = (tgtCx - w / 2f).toInt()
                it.topMargin = (tgtCy - h / 2f).toInt()
            }
            pivotX = w / 2f; pivotY = h / 2f
            alpha = 0f
        }
        root.addView(tv)

        val lp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_NAVIGATION_BAR_PANEL,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { setTitle("ClockMorphOverlay") }
        wm.addView(root, lp)
        current = root

        val tgtScale = (tgtH / srcH).coerceIn(0.2f, 1f)
        fun clamp(v: Float) = v.coerceIn(0f, 1f)

        fun apply(p: Float) {
            if (cfg.mode == 0) {
                iv.translationX = (tgtCx - srcCx) * p
                iv.translationY = (tgtCy - srcCy) * p
                val sc = 1f + (tgtScale - 1f) * p
                iv.scaleX = sc; iv.scaleY = sc
                iv.alpha = 1f - clamp(p / 0.55f)

                tv.translationX = (srcCx - tgtCx) * (1f - p)
                tv.translationY = (srcCy - tgtCy) * (1f - p)
                val ts = 1.5f - 0.5f * p
                tv.scaleX = ts; tv.scaleY = ts
                tv.alpha = clamp((p - 0.35f) / 0.65f)
            } else {
                iv.translationY = -60f * density * p
                iv.alpha = 1f - p
                tv.alpha = 0f
            }
        }

        val from = if (reverse) 1f else 0f
        val to = if (reverse) 0f else 1f
        apply(from)
        animator = ValueAnimator.ofFloat(from, to).apply {
            duration = cfg.durationMs
            interpolator = PathInterpolator(0.2f, 0f, 0f, 1f)
            addUpdateListener { apply(it.animatedValue as Float) }
            addListener(object : AnimatorListenerAdapter() {
                private var canceled = false
                override fun onAnimationCancel(a: Animator) { canceled = true }
                override fun onAnimationEnd(a: Animator) {
                    if (canceled) return
                    if (reverse) {
                        removeNow()
                    } else {
                        // tahan sebentar lalu pudar supaya widget asli di bawahnya terlihat
                        root.animate().alpha(0f).setStartDelay(120).setDuration(220)
                            .withEndAction { if (current === root) removeNow() }.start()
                    }
                }
            })
            start()
        }
    }
}
