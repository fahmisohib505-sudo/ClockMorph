package com.xos.clockmorph

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.PathInterpolator
import android.widget.FrameLayout
import android.widget.TextView
import de.robv.android.xposed.XposedHelpers

/**
 * Overlay animasi di proses SystemUI (v2).
 * Angka jam ("03") dan menit ("43") jam lockscreen ditiru sebagai dua TextView (font, ukuran, posisi
 * sama persis), lalu keduanya bergeser & mengecil sendiri-sendiri menjadi satu baris "03:43"
 * di posisi widget. Arah dibalik saat layar dikunci lagi.
 */
object MorphOverlay {

    // TYPE_NAVIGATION_BAR_PANEL (hidden API) = 2024
    private const val TYPE_NAV_BAR_PANEL = 2024

    class Config(
        val mode: Int,
        val durationMs: Long,
        val targetXPercent: Int,
        val targetYPercent: Int,
        val targetHeightDp: Int,
    )

    /** Info satu angka (jam atau menit) dari KeyguardClockView. */
    class Part(
        val text: CharSequence,
        val left: Int, val top: Int, val w: Int, val h: Int,
        val textSizePx: Float,
        val gravity: Int,
        val padL: Int, val padT: Int, val padR: Int, val padB: Int,
        val fontPadding: Boolean,
        val typeface: Typeface?,
        val variation: String?,
        val color: Int,
    )

    class Snapshot(val context: Context, val hour: Part, val minute: Part)

    private val main = Handler(Looper.getMainLooper())
    private var current: View? = null
    private var animator: ValueAnimator? = null

    private fun part(v: TextView): Part? {
        if (v.width <= 0 || v.height <= 0 || !v.isAttachedToWindow) return null
        val loc = IntArray(2)
        v.getLocationOnScreen(loc)
        return Part(
            text = v.text, left = loc[0], top = loc[1], w = v.width, h = v.height,
            textSizePx = v.textSize, gravity = v.gravity,
            padL = v.paddingLeft, padT = v.paddingTop, padR = v.paddingRight, padB = v.paddingBottom,
            fontPadding = v.includeFontPadding, typeface = v.typeface,
            variation = try { v.fontVariationSettings } catch (_: Throwable) { null },
            color = v.currentTextColor,
        )
    }

    /** Baca angka jam & menit dari KeyguardClockView. Null kalau belum siap digambar. */
    fun snapshot(clockView: View): Snapshot? {
        val hv = XposedHelpers.callMethod(clockView, "getTimeViewHour") as? TextView ?: return null
        val mv = XposedHelpers.callMethod(clockView, "getTimeViewMinute") as? TextView ?: return null
        val h = part(hv) ?: return null
        val m = part(mv) ?: return null
        return Snapshot(clockView.context, h, m)
    }

    fun play(s: Snapshot, cfg: Config, reverse: Boolean) {
        main.post {
            try { run(s, cfg, reverse) } catch (t: Throwable) {
                de.robv.android.xposed.XposedBridge.log("ClockMorph overlay: $t")
                removeNow()
            }
        }
    }

    private fun removeNow() {
        animator?.cancel(); animator = null
        current?.let {
            try { it.context.getSystemService(WindowManager::class.java).removeViewImmediate(it) }
            catch (_: Throwable) {}
        }
        current = null
    }

    private fun replica(ctx: Context, p: Part): TextView = TextView(ctx).apply {
        text = p.text
        setTextSize(TypedValue.COMPLEX_UNIT_PX, p.textSizePx)
        setTextColor(p.color)
        typeface = p.typeface
        try { if (p.variation != null) fontVariationSettings = p.variation } catch (_: Throwable) {}
        includeFontPadding = p.fontPadding
        gravity = p.gravity
        setPadding(p.padL, p.padT, p.padR, p.padB)
        layoutParams = FrameLayout.LayoutParams(p.w, p.h, Gravity.TOP or Gravity.START).also {
            it.leftMargin = p.left; it.topMargin = p.top
        }
        pivotX = p.w / 2f; pivotY = p.h / 2f
    }

    private fun run(s: Snapshot, cfg: Config, reverse: Boolean) {
        removeNow()
        val ctx = s.context
        val wm = ctx.getSystemService(WindowManager::class.java)
        val dm = ctx.resources.displayMetrics
        val density = dm.density

        val root = FrameLayout(ctx)
        val hv = replica(ctx, s.hour)
        val mv = replica(ctx, s.minute)
        root.addView(hv); root.addView(mv)

        // Target: satu baris "HH:mm" berpusat di posisi widget, font sama dengan jam lockscreen
        val tgtSize = cfg.targetHeightDp * density
        val scale = tgtSize / s.hour.textSizePx
        val paint = Paint().apply {
            textSize = tgtSize; typeface = s.hour.typeface
            try { if (s.hour.variation != null) fontVariationSettings = s.hour.variation } catch (_: Throwable) {}
        }
        val wH = paint.measureText(s.hour.text.toString())
        val wC = paint.measureText(":")
        val wM = paint.measureText(s.minute.text.toString())
        val total = wH + wC + wM
        val tgtCx = dm.widthPixels * cfg.targetXPercent / 100f
        val tgtCy = dm.heightPixels * cfg.targetYPercent / 100f
        val startX = tgtCx - total / 2f
        val hCx = startX + wH / 2f
        val cCx = startX + wH + wC / 2f
        val mCx = startX + wH + wC + wM / 2f

        val colon = TextView(ctx).apply {
            text = ":"
            setTextSize(TypedValue.COMPLEX_UNIT_PX, tgtSize)
            setTextColor(s.hour.color)
            typeface = s.hour.typeface
            includeFontPadding = s.hour.fontPadding
            measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED)
            layoutParams = FrameLayout.LayoutParams(measuredWidth, measuredHeight, Gravity.TOP or Gravity.START)
                .also {
                    it.leftMargin = (cCx - measuredWidth / 2f).toInt()
                    it.topMargin = (tgtCy - measuredHeight / 2f).toInt()
                }
            alpha = 0f
        }
        root.addView(colon)

        val hSrcCx = s.hour.left + s.hour.w / 2f
        val hSrcCy = s.hour.top + s.hour.h / 2f
        val mSrcCx = s.minute.left + s.minute.w / 2f
        val mSrcCy = s.minute.top + s.minute.h / 2f

        val lp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT,
            TYPE_NAV_BAR_PANEL,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { setTitle("ClockMorphOverlay") }
        wm.addView(root, lp)
        current = root

        fun clamp(v: Float) = v.coerceIn(0f, 1f)
        fun apply(p: Float) {
            if (cfg.mode == 0) {
                val sc = 1f + (scale - 1f) * p
                hv.translationX = (hCx - hSrcCx) * p
                hv.translationY = (tgtCy - hSrcCy) * p
                hv.scaleX = sc; hv.scaleY = sc
                mv.translationX = (mCx - mSrcCx) * p
                mv.translationY = (tgtCy - mSrcCy) * p
                mv.scaleX = sc; mv.scaleY = sc
                colon.alpha = clamp((p - 0.55f) / 0.45f)
            } else {
                val dy = -60f * density * p
                hv.translationY = dy; mv.translationY = dy
                hv.alpha = 1f - p; mv.alpha = 1f - p
                colon.alpha = 0f
            }
        }

        val from = if (reverse) 1f else 0f
        val to = if (reverse) 0f else 1f
        apply(from)
        animator = ValueAnimator.ofFloat(from, to).apply {
            duration = cfg.durationMs
            interpolator = PathInterpolator(0.2f, 0f, 0f, 1f)
            addUpdateListener { apply(it.animatedValue as Float) }
            addListener(object : AnimatorListenerAdapter() {
                private var canceled = false
                override fun onAnimationCancel(a: Animator) { canceled = true }
                override fun onAnimationEnd(a: Animator) {
                    if (canceled) return
                    if (reverse) {
                        removeNow()
                    } else {
                        // tahan sampai animasi buka launcher selesai, lalu pudar ke widget asli
                        root.animate().alpha(0f).setStartDelay(350).setDuration(250)
                            .withEndAction { if (current === root) removeNow() }.start()
                    }
                }
            })
            start()
        }
    }
}
