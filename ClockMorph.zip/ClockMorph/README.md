# Clock Morph XOS 16.3

Modul LSPosed untuk XOS 16.3 (UI Sistem 16.03.00.123). Efek: jam vertikal lockscreen mengecil dan
mendarat jadi jam horizontal di widget homescreen saat unlock, dan sebaliknya saat dikunci.

## Build
1. Buka folder ini di Android Studio, tunggu Gradle sync (butuh internet; repo Xposed API: https://api.xposed.info/).
2. Build > Build APK(s), lalu pasang APK-nya.

## Pemakaian
1. LSPosed > Modul > aktifkan "Clock Morph XOS", scope: **System UI** saja.
2. Restart SystemUI / reboot.
3. Tambahkan widget "Clock Morph XOS" di homescreen, taruh di bagian atas.
4. Buka app Clock Morph XOS: pilih mode animasi (1 Morph, 2 Geser & pudar), durasi,
   lalu samakan Posisi X/Y dan Tinggi teks dengan letak widget Anda.

## Hook (semua diambil dari dex SystemUI 16.03.00.123)
- `com.transsion.keyguard.clock.ui.KeyguardClockView` : onAttachedToWindow/onDetachedFromWindow,
  getTimeContainer(), getTimeViewHour()
- `com.android.systemui.statusbar.policy.KeyguardStateControllerImpl` :
  notifyKeyguardGoingAway(boolean), notifyKeyguardState(boolean, boolean)

## Catatan
- AOD: jam AOD memakai KeyguardClockView yang sama dengan lockscreen
  (`TranAodAnimController.mKeyguardClockView`), jadi transisi lockscreen <-> AOD sudah memakai satu
  view dan tidak perlu hook tambahan.
- Belum diuji di perangkat. Kalau animasi tidak muncul, lihat log LSPosed (cari "ClockMorph").
- Angka jam & menit dianimasikan memakai font asli lockscreen; widget memakai sans-serif-light.
